package com.example.tripbookingmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripbookingmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
