package com.example.tripbooking.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String typeOfSeat;
    private int seatNumber;
    private int capacity;
    private String typeOfFood;
	public String getTypeOfSeat() {
		return typeOfSeat;
	}
	public void setTypeOfSeat(String typeOfSeat) {
		this.typeOfSeat = typeOfSeat;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public String getTypeOfFood() {
		return typeOfFood;
	}
	public void setTypeOfFood(String typeOfFood) {
		this.typeOfFood = typeOfFood;
	}
	@Override
	public String toString() {
		return "Flight [typeOfSeat=" + typeOfSeat + ", seatNumber=" + seatNumber + ", capacity=" + capacity
				+ ", typeOfFood=" + typeOfFood + "]";
	}
}