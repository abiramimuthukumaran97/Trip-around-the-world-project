package com.example.tripbooking.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TravelBooking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String travellerName;
    private String typeOfFlight;
    private int travelDate;
	public String getTravellerName() {
		return travellerName;
	}
	public void setTravellerName(String travellerName) {
		this.travellerName = travellerName;
	}
	public String getTypeOfFlight() {
		return typeOfFlight;
	}
	public void setTypeOfFlight(String typeOfFlight) {
		this.typeOfFlight = typeOfFlight;
	}
	public int getTravelDate() {
		return travelDate;
	}
	public void setTravelDate(int travelDate) {
		this.travelDate = travelDate;
	}
	@Override
	public String toString() {
		return "travelbooking [travellerName=" + travellerName + ", typeOfFlight=" + typeOfFlight + ", travelDate="
				+ travelDate + "]";
	}
}