package com.example.tripbookingmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripbookingmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripbookingmanagementApplication.class, args);
		System.out.println("connected successfully");
	}

}
